import {Component} from '@angular/core';
import {HomeComponent} from './home/home.component';
import {RouterLink, RouterOutlet} from '@angular/router';
import { url } from 'inspector';
@Component({
  selector: 'app-root',
  imports: [HomeComponent, RouterLink, RouterOutlet],
  templateUrl:"app.component.html",
  styleUrls: ['./app.component.css'],
})  
export class AppComponent {
  title = 'homes';
}
﻿using System;
using System.Text;
using System.Windows;

namespace PasswordGeneratorApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void GeneratePassword_Click(object sender, RoutedEventArgs e)
        {
            int passwordLength;
            if (!int.TryParse(PasswordLengthTextBox.Text, out passwordLength) || passwordLength <= 0)
            {
                MessageBox.Show("Podaj poprawną długość hasła.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            const string letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string digits = "0123456789";
            const string special = "!@#$%^&*()_+-=";

            var characterPool = new StringBuilder();
            var random = new Random();

           
            if (IncludeLettersCheckBox.IsChecked == true)
                characterPool.Append(letters);

            if (IncludeDigitsCheckBox.IsChecked == true)
                characterPool.Append(digits);

            if (IncludeSpecialCheckBox.IsChecked == true)
                characterPool.Append(special);

            if (characterPool.Length == 0)
            {
                MessageBox.Show("Wybierz co najmniej jedną opcję znaków.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

           
            var password = new StringBuilder();
            for (int i = 0; i < passwordLength; i++)
            {
                var randomIndex = random.Next(characterPool.Length);
                password.Append(characterPool[randomIndex]);
            }

           
            MessageBox.Show(password.ToString(), "Wygenerowane hasło", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Confirm_Click(object sender, RoutedEventArgs e)
        {
            
            string name = NameTextBox.Text;
            string surname = SurnameTextBox.Text;
            string position = PositionComboBox.Text;

           
            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(surname) || string.IsNullOrWhiteSpace(position))
            {
                MessageBox.Show("Uzupełnij wszystkie pola danych pracownika.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            
            string message = $"Dane pracownika: {name} {surname}, {position}";
            MessageBox.Show(message, "Podsumowanie", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}